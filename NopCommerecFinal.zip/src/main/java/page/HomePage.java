package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class HomePage {
    WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public String getTitle() {
        return driver.getTitle();
    }

    public void clickComputersDropdown() {
        WebElement computersMenu = driver.findElement(By.linkText("Computers"));
        Actions actions = new Actions(driver);
        actions.moveToElement(computersMenu).perform();
    }

    public void selectDesktops() {
        driver.findElement(By.linkText("Desktops")).click();
    }

    public void clickOnFirstFeaturedProduct() {
        WebElement firstProduct = driver.findElement(By.cssSelector(".product-item .product-title a"));
        firstProduct.click();
    }
}
