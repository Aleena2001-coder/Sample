package test;

import page.HomePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.time.Duration;

public class HomePageTest {
    WebDriver driver;
    HomePage homePage;

    @BeforeClass
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "chromedriver");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://demo.nopcommerce.com/");
        homePage = new HomePage(driver);
    }

    @Test(priority = 1)
    public void handleTitle() {
        System.out.println("Title: " + homePage.getTitle());
    }

    @Test(priority = 2)
    public void clickComputerAndSelectDesktop() {
        homePage.clickComputersDropdown();
        homePage.selectDesktops();
    }

    @Test(priority = 3)
    public void addToCart() {
        driver.findElement(By.cssSelector("button.button-2.product-box-add-to-cart-button")).click();
    }

    @Test(priority = 4)
    public void searchItem() {
        driver.findElement(By.id("small-searchterms")).sendKeys("laptop");
        driver.findElement(By.cssSelector("button[type='submit']")).click();
    }

    @Test(priority = 5)
    public void likeItem() {
        driver.findElement(By.cssSelector(".add-to-wishlist-button")).click();
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
